//
//  AppDelegate.swift
//  Yash_Sharma_FE_8942955
//
//  Created by user233747 on 12/6/23.
//

import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        setupCoreData()
        return true
    }

    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "Yash_Sharma_FE_8942955") // Replace with your actual data model name
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Setup

    func setupCoreData() {
        // Function to set up Core Data, you can add your specific setup code here
        // E.g., check if initial data needs to be loaded
    }

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

    // MARK: - Helper Function for News_data Entity

    func createNewsData(author: String, source: String, title: String) {
        let context = persistentContainer.viewContext
        let newsData = News_data(context: context)
        newsData.author = author
        newsData.source = source
        newsData.title = title
        saveContext()
    }
}

