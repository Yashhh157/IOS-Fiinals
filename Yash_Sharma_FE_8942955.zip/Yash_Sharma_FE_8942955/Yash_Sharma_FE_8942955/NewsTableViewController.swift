//
//  NewsTableViewController.swift
//  Yash_Sharma_FE_8942955
//
//  Created by user233747 on 12/8/23.
//

import UIKit

class NewsTableViewController: UITableViewController {
    
    @IBAction func addButton(_ sender: UIBarButtonItem) {
        showCityAlert()

    }
    
    var newsArticles: [NewsArticle] = []
    
    var city: String?
    var selectedCity: String = "Waterloo" // Default city
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("news")
        
        if let city = city {
            fetchNewsForCity(city)
        }
        else{
            fetchNewsForCity(selectedCity)
        }
    }
    
    func showCityAlert(){
        let alert = UIAlertController(title: "Where would you like to go?",message: "Enter your new destination", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK",style: .default, handler: {action in if let cityName = alert.textFields?.first?.text, !cityName.isEmpty {
            self.fetchNewsForCity(cityName)
            }
            else{
                self.showAlert(message: "Please enter the name of the city")
            }
            }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {action in print("tapped Directions")}))
      
        alert.addTextField{field in field.placeholder = "Write a place"}
        
        present(alert, animated: true)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Table view data source
    func fetchNewsForCity(_ city: String) {
            let apiKey = "e87cb28a0fa541ce897b00d4d32c46bd"
            let urlString = "https://newsapi.org/v2/everything?q=\(city)&apiKey=\(apiKey)"
            print("city \(urlString)")
            if let url = URL(string: urlString) {
                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    if let error = error {
                        print("Error fetching data: \(error)")
                        return
                    }
                    
                    guard let data = data else {
                        print("No data received")
                        return
                    }
                    
                    do {
                        let decoder = JSONDecoder()
                        let newsResponse = try decoder.decode(NewsResponse.self, from: data)
                        self.newsArticles = newsResponse.articles
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                            print("Data updated and table reloaded")

                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                    
                    }
                }
                task.resume()
            }
        }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return newsArticles.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell", for: indexPath) as! NewsCustomTableViewCell
           
           let article = newsArticles[indexPath.row]
           print(article.title)
           cell.titleLabel.text = "Title: " + (article.title )
           cell.titleLabel.numberOfLines = 2 // Set maximum lines to 3
           cell.descriptionLabel.text = "Content Description: " + (article.description ?? "")
           cell.descriptionLabel.numberOfLines = 5 // Set maximum lines to 3
           cell.authorLabel.text = "Author: " + (article.author ?? "Unknown")
           cell.authorLabel.numberOfLines = 2 // Set maximum lines to 3
           cell.sourceLabel.text = "Source: " + (article.source.name)
        
           return cell
       }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Return your desired cell height
        return 250 // Set the height you want
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

struct NewsResponse: Codable {
    let articles: [NewsArticle]
}

struct NewsArticle: Codable {
    let title: String
    let description: String?
    let author: String?
    let source: NewsSource
}

struct NewsSource: Codable {
    let name: String
}
