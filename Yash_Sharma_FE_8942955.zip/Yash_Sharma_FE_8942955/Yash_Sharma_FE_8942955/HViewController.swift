import UIKit

struct ToDo: Codable {
    var text: String
    var complete: Bool
}

class HViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView! // Connect this to your actual table view in the storyboard

    var toDos = [ToDo]()

    override func viewDidLoad() {
        super.viewDidLoad()

        loadToDos()

        // Set the delegate and data source for the table view
        tableView.delegate = self
        tableView.dataSource = self
    }


    func saveToDos() {
        let encodedData = try? JSONEncoder().encode(toDos)
        UserDefaults.standard.set(encodedData, forKey: "toDos")
    }

    func loadToDos() {
        if let data = UserDefaults.standard.data(forKey: "toDos"),
           let savedToDos = try? JSONDecoder().decode([ToDo].self, from: data) {
            toDos = savedToDos
            tableView.reloadData()
        }
    }

    // MARK: - Table View Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDos.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let toDo = toDos[indexPath.row]

        let cell = UITableViewCell()
        cell.textLabel?.text = toDo.text

        if toDo.complete {
            cell.accessoryType = .checkmark
            cell.textLabel?.alpha = 0.5
        } else {
            cell.accessoryType = .none
            cell.textLabel?.alpha = 1.0
        }

        return cell
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            toDos.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            saveToDos()
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        toDos[indexPath.row].complete.toggle()
        tableView.reloadData()
        saveToDos()
    }
}
